package com.swoqe.parrot.configuration.service

enum class TemplateType {
    STANDALONE,
    STANDALONE_VPC,
    ALB_SCALING_VPC
}