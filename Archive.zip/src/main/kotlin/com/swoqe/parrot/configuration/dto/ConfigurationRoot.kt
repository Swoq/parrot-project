package com.swoqe.parrot.configuration.dto

data class ConfigurationRoot(var name: String?, var docker: Docker, var aws: Aws)
