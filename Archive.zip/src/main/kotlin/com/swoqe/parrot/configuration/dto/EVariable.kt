package com.swoqe.parrot.configuration.dto

data class EVariable(
    var name: String,
    var value: String
)
